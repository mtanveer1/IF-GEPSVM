close all;clear all;clc;

Training_data=load("train.csv");
testing_data=load("test.csv");

kerfpara.pars=2^(3);
kerfpara.type='rbf';
ep=2^(3);
[ auc]=IF_GEPSVM(Training_data,testing_data,ep,kerfpara);

display(auc)