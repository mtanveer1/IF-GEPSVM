function [accuracy]=IF_IGEPSVM(C,test_data,ep,delta,kerfPara)

mew=kerfPara.pars;
[m,~]=size(C);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A1=C(C(:,end)==1,1:end-1);
B1=C(C(:,end)~=1,1:end-1);
label=C(:,end);
K1 = exp(-(1/(mew^2))*(repmat(sqrt(sum(A1.^2,2).^2),1,size(A1,1))-2*(A1*A1')+repmat(sqrt(sum(A1.^2,2)'.^2),size(A1,1),1)));
K2 = exp(-(1/(mew^2))*(repmat(sqrt(sum(B1.^2,2).^2),1,size(B1,1))-2*(B1*B1')+repmat(sqrt(sum(B1.^2,2)'.^2),size(B1,1),1)));
A_temp=C(:,1:end-1);
K3 = exp(-(1/(mew^2))*(repmat(sqrt(sum(A_temp.^2,2).^2),1,size(A_temp,1))-2*(A_temp*A_temp')+repmat(sqrt(sum(A_temp.^2,2)'.^2),size(A_temp,1),1)));

radiusxp=sqrt(1-2*mean(K1,2)+mean(mean(K1)));
radiusmaxxp=max(radiusxp);
radiusxn=sqrt(1-2*mean(K2,2)+mean(mean(K2)));
radiusmaxxn=max(radiusxn);

alpha_d=max(radiusmaxxn,radiusmaxxp);

mem=[];
j=1;k=1;
for i=1:m
    if(label(i)==1)
        membership=1-(radiusxp(j)/(radiusmaxxp+10^-4));
        j=j+1;
    else
        membership=1-(radiusxn(k)/(radiusmaxxn+10^-4));
        k=k+1;
    end
    mem=[mem membership];
end

ro=[];
DD=sqrt(2*(ones(size(K3))-K3));
for i=1:m

    temp=DD(i,:)';
    C1=C(temp<alpha_d,:);

    [x3,~]=size(B1);
    count=sum(C(i,end)*ones(size(C1,1),1)~=C1(:,end));

    x5=count/x3;
    ro=[ro;x5];
end

v=(ones(size(mem))-mem).*ro;

S=[];
for i=1:size(v,1)
    if v(i)==0
        S=[S;mem(i)];
    elseif (mem(i)<=v(i))
        S=[S;0];
    else
        S=[S;(1-v(i))/(2-mem(i)-v(i))];
    end
end

A=[];
B=[];
Amem = [];
Bmem = [];
for i = 1:m
    if(label(i) == 1)
        A = [A;C(i,1:end-1)];
        Amem=[Amem;S(i)];
    else
        B = [B;C(i,1:end-1)];
        Bmem=[Bmem;S(i)];
    end
end

S1=diag(Amem);
S2=diag(Bmem);

%%%%%%%%%%%%%%%%%%%%%%%% Train%%%%%%%%%%%%%%%%%%%

m1=size(A,1);
m2=size(B,1);
n=size(A,2);

e1=ones(m1,1);
e2=ones(m2,1);

if strcmp(kerfPara.type,'lin')
    M=[S1*A S1*e1]'*[S1*A S1*e1];
    H=[S2*B S2*e2]'*[S2*B S2*e2];

    I1=(M'+delta*eye(n+1))-ep*H';
    I2=(H'+delta*eye(n+1))-ep*M';

else
    C=[A;B];
    m4=size(C,1);
    kA = kernelfun(A,kerfPara,C);
    kB = kernelfun(B,kerfPara,C);

    M=[S1*kA S1*e1]'*[S1*kA S1*e1];
    H=[S2*kB S2*e2]'*[S2*kB S2*e2];

    I1=(M'+delta*eye(m4+1))-ep*H';
    I2=(H'+delta*eye(m4+1))-ep*M';
end

[X1,Y1]=eig(I1);
Y1=diag(Y1);
[Y1,index1]=min(Y1);

[X2,Y2]=eig(I2);
Y2=diag(Y2);
[Y2,index2]=min(Y2);

vector1=X1(:,index1(1,1));
vector2=X2(:,index2(1,1));

w1=vector1(1:end-1,1);
w2=vector2(1:end-1,1);
b1=vector1(end,1);
b2=vector2(end,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predict and output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TestX=test_data(:,1:end-1);
TestY=test_data(:,end);

m=size(TestX,1);
if strcmp(kerfPara.type,'lin')
    H=TestX;
    w11=sqrt(w1'*w1);
    w22=sqrt(w2'*w2);
    y1=H*w1+b1*ones(m,1);
    y2=H*w2+b2*ones(m,1);
else
    H=kernelfun(TestX,kerfPara,C);
    w11=sqrt(w1'*kernelfun(C,kerfPara,C)*w1);
    w22=sqrt(w2'*kernelfun(C,kerfPara,C)*w2);
    y1=H*w1+b1*ones(m,1);
    y2=H*w2+b2*ones(m,1);
end
wp=sqrt(2+2*w1'*w2/(w11*w22));
wm=sqrt(2-2*w1'*w2/(w11*w22));
clear H; clear C;

m1=y1/w11;
m2=y2/w22;
MP=(m1+m2)/wp;
MN=(m1-m2)/wm;
mind=min(abs(MP),abs(MN));
maxd=max(abs(MP),abs(MN));
Predict_Y = sign(abs(m2)-abs(m1));

match = 0.;
match1=0;
classifier = Predict_Y;
obs1 = TestY;
posval=0;
negval=0;
no_test=length(TestY);
for i = 1:no_test
    if(obs1(i)==1)
        if(classifier(i) == obs1(i))
            match = match+1;
        end
        posval=posval+1;
    elseif(obs1(i)==-1)
        if(classifier(i) ~= obs1(i))
            match1 = match1+1;
        end
        negval=negval+1;
    end
end
if(posval~=0)
    a_pos=(match/posval);
else
    a_pos=0;
end

if(negval~=0)
    am_neg=(match1/negval);
else
    am_neg=0;
end

AUC=sum(classifier==obs1)/length(obs1);
accuracy=AUC*100;

end