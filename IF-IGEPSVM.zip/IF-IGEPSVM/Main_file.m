close all;clear all;clc;

Training_data=load("train.csv");
testing_data=load("test.csv");

kerfpara.pars=2^(3);
kerfpara.type='rbf';
ep=2^(3);
delta=2^(-1);
[ auc]=IF_IGEPSVM(Training_data,testing_data,ep,delta,kerfpara);

display(auc)